// import { createTheme } from 'react-data-table-component'

// createTheme('solarized', {}, 'dark');

export const paginationOptions = {
  rowsPerPageText: 'Filas por página',
  rangeSeparatorText: 'de',
  selectAllRowsItem: true,
  selectAllRowsItemText: 'Todos',
}
